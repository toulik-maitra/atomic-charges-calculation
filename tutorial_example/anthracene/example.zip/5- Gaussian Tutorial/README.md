1. Extract the one molecule from the Unitcell using ASE (one_molecule.py), and make sure same number of atoms is there same as one molecule. 
2. Create Gaussian Input for Geometry Optimization -> you will get .chk file
3. Extract the optimized geormetry from .log file -> use that for wavefunction calculations
4. Create a new job submission file using ASE, make sure you are changing the job.com in terms of .wfx calculation.
5. Use Chargemol to calculate the atomic charges and Bond Order.
   - To isntall Chargemol: Download chargemol.zip from https://sourceforge.net/projects/ddec/
   - Extract the file and copy upload that to $HOME
   - Create a directory bin/
   - Copy the executable Chargemol_09_26_2017_linux_parallel to bin/ ; and make it execulable by chmod +x Chargemol_09_26_2017_linux_parallel
   - Copy the atomic densities into bin/
   - Edit the job_control.txt to calculate the desired properties